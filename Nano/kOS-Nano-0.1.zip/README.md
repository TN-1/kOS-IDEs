# kOS-IDEs
This plugin enables support for kOS syntax highlighting in the Nano editor for Linux/Unix systems and Windows through Cygwin.
http://www.nano-editor.org/
http://ksp-kos.github.io/KOS_DOC/

###INSTALL###
The following commands will require the use of root privillages 
Copy ks.nanorc to /usr/share/nano
Add(Verbatim, Dont change unless you know what you are doing).. include "/usr/share/nano/ks.nanorc" ..to the nanorc config located at /etc/nanorc